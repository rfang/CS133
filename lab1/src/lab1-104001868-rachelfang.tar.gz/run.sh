#!/bin/bash

./dwt3d $1 16 $2
